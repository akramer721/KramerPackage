#' Fire Data Set
#' @format A data frame with 15 rows and 2 variables:
"fire"
