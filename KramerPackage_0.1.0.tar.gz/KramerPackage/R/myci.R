#' Calculating Confidence Intervals
#' @title Confidence Interval Calculation
#' @param x is the data set
#' @param int is a value between 0 and 1, the percentage of which the desired confidence interval will be made.
#' @return Confidence Interval
#' @export


myci=function(x,int){

t=qt(int,(length(x)-1))
ci=c()
ci[1]=mean(x)-t*sd(x)/sqrt(length(x)-1)
ci[2]=mean(x)+t*sd(x)/sqrt(length(x)-1)
ci

}

