#' Plot normal distribution.
#' @title Normal Distribution Plotting
#' @param mu is the mean of the desired distribution
#' @param sigma is the standard deviation of the distribution
#' @param a is a vector of values
#' @return Normal distribution plot with probabilities
#' @export
#'
myncurve = function(mu,sigma,a) {
  curve(dnorm(x,mean=mu,sd=sigma), xlim = c(mu-3*sigma, mu+3*sigma), col = "black")

  xcurve=seq(-100000,a,length=10000000)
  ycurve=dnorm(xcurve,mean=mu,sd=sigma)
  polygon(c(-100000,xcurve,a),c(0,ycurve,0),col="gray17")

  prob=pnorm(a,mean=mu,sd=sigma)
  prob=round(prob,4)
  prob


  text(x=(a*2.5), y=(0.5*dnorm(a/2, mu, sigma)) , paste("Area = ", prob, sep=""))
}

