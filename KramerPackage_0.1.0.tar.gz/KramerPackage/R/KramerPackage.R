#' Kramer Package
#'
#' Contains several equations for MATH4753
#'
#' @docType package
#'
#' @author Andrew Kramer \email{andrewgkramer@ou.edu}
#'
#' @name KramerPackage
NULL
