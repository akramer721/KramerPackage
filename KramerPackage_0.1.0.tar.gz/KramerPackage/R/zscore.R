#' Create Z-Score
#'
#' @title Z-Scores
#' @param x is a vector of values
#'
#' @return a vector of z-scores for each value in x
#' @export
#'
zscore=function(x){
  x = (x-mean(x))/sd(x)
}
